var accessRequestArchivalPluginUrl = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=AccessRequestArchivalPlugin';

jQuery(document).ready(function() {

	if (jQuery('#access-req-archival-nav').length > 0) {
		return;
	}
	jQuery('ul.navbar-right').prepend(
		'<li id="access-req-archival-nav">' +
		' <a id="access-req-archival-link" href="' + accessRequestArchivalPluginUrl + '" title="Access Request">' +
		'   <i class="fa fa-list-alt fa-lg"></i>' +
		' </a>' +
		'</li>'
	);
});

jQuery(document).on('click', '#access-req-archival-link', function(e) {
	sessionStorage.setItem("fromAccessArchivalIcon", "true");
	e.stopImmediatePropagation();
	window.location.href = this.href;
});
