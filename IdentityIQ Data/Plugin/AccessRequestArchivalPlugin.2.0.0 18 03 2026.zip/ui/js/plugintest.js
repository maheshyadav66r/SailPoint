angular.module('AccessRequestArchivalPlugin', ['ui.bootstrap', 'sailpoint.dataview'])
	.config(['$httpProvider', function($httpProvider) {
		$httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
	}])

	.controller('plugintest', ['$http', '$document', '$timeout', '$window', function($http, $document, $timeout, $window) {
		var ctrl = this;

		// ================================
		//  INITIAL VARIABLES
		// ================================
		ctrl.requests = [];
		ctrl.page = 1;
		ctrl.size = 10;
		ctrl.total = 0;
		ctrl.showDiv = false;
		ctrl.errorMessage = "";
		ctrl.searchTerm = "";
		ctrl.showFilterPanel = false;
		ctrl.pageButtonWidth = 40; // Width per page button for rail scrolling
		ctrl.searchValue = "";

		ctrl.showScrollTop = false;
		ctrl.showScrollBottom = false;

		ctrl.scrollToTop = function() {
			$window.scrollTo({ top: 0, behavior: 'smooth' });
		};

		ctrl.scrollToBottom = function() {
			var height = $document[0].body.scrollHeight;
			$window.scrollTo({ top: height, behavior: 'smooth' });
		};

		var scrollDebounceTimer = null;
		angular.element($window).on('scroll', function() {
			if (scrollDebounceTimer) {
				$timeout.cancel(scrollDebounceTimer);
			}
			scrollDebounceTimer = $timeout(function() {
				var scrollTop = $window.pageYOffset || $document[0].documentElement.scrollTop;
				var windowHeight = $window.innerHeight;
				var docHeight = $document[0].body.scrollHeight;

				ctrl.showScrollTop = scrollTop > 200;
				ctrl.showScrollBottom = (scrollTop + windowHeight) < (docHeight - 200);
			}, 100);
		});
		// -------------------------------
		// SORT DROPDOWN CONFIGURATION
		// -------------------------------

		// Array of sort options
		ctrl.sortOptions = ["Date", "Completion Date", "Request ID", "Requestee", "Requester", "Priority"];

		// Currently selected sort
		ctrl.selectedSort = "Date";

		// Dropdown open/close flag
		ctrl.isSortMenuOpen = false;

		// Toggle dropdown
		ctrl.toggleSortMenu = function(event) {
			event.stopPropagation(); // prevent bubbling
			ctrl.isSortMenuOpen = !ctrl.isSortMenuOpen;
		};

		// Select an option
		ctrl.selectSortOption = function(option) {
			ctrl.selectedSort = option;
			ctrl.isSortMenuOpen = false;

			// Reset page to 1 whenever sort option changes
			ctrl.page = 1;
			// Trigger backend call based on mode
			if (ctrl.isFilterMode) {
				// Fetch filtered requests with new sort
				ctrl.applyFilter(true); // true = pagination/refresh call
			} else {
				// Fetch search results with new sort
				ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
			}
		};

		// Close dropdown when clicking outside
		document.addEventListener('click', function(event) {
			var dropdown = document.querySelector('.custom-sort-container');
			if (dropdown && !dropdown.contains(event.target) && ctrl.isSortMenuOpen) {
				$timeout(function() {
					ctrl.isSortMenuOpen = false;
				});
			}
		});

		// ==============================
		// INITIAL SAFE STATE (MANDATORY)
		// ==============================

		ctrl.archivalIRIdentities = [];
		ctrl.archivalIRApplications = [];

		ctrl.archivalIRRequestersToShow = [];
		ctrl.archivalIRRequesteesToShow = [];
		ctrl.archivalIRApplicationsToShow = [];

		ctrl.searchRequester = "";
		ctrl.searchRequestee = "";
		ctrl.searchApplication = "";

		ctrl.showRequesterDropdown = false;
		ctrl.showRequesteesDropdown = false;
		ctrl.showApplicationDropdown = false;

		ctrl.requestersList = [];

		ctrl.requesterLimit = 5;
		ctrl.requesterOffset = 0;

		ctrl.isRequesterLoading = false;
		ctrl.hasMoreRequesterData = true;


		// ================================
		// Requester Dropdown FULL WORKING
		// ================================

		var requesterDebouncePromise = null;

		// 🔹 Reset State
		ctrl.resetRequesterState = function() {
			ctrl.requesterLimit = 5;
			ctrl.requestersList = [];
			ctrl.hasMoreRequesterData = true;
		};


		// 🔹 Open Dropdown (NO duplicate fetch)
		ctrl.openRequesterDropdown = function() {
			if (ctrl.showRequesterDropdown) return;

			ctrl.showRequesterDropdown = true;
			ctrl.resetRequesterState();
			ctrl.fetchRequesters();
		};


		// 🔹 Toggle Dropdown
		ctrl.toggleRequesterDropdown = function() {
			ctrl.showRequesterDropdown = !ctrl.showRequesterDropdown;

			if (ctrl.showRequesterDropdown) {
				ctrl.resetRequesterState();
				ctrl.fetchRequesters();
			}
		};


		// 🔹 Debounced Search
		ctrl.onRequesterSearchChange = function() {

			if (!ctrl.showRequesterDropdown) {
				ctrl.showRequesterDropdown = true;
			}

			if (requesterDebouncePromise) {
				$timeout.cancel(requesterDebouncePromise);
			}

			requesterDebouncePromise = $timeout(function() {
				ctrl.resetRequesterState();
				ctrl.fetchRequesters();
			}, 400);
		};


		// 🔹 Fetch API
		ctrl.fetchRequesters = function() {

			if (ctrl.isRequesterLoading || !ctrl.hasMoreRequesterData) {
				return;
			}

			ctrl.isRequesterLoading = true;

			$http.get(
				PluginHelper.getPluginRestUrl(
					"AccessRequestArchivalPlugin/search/identityNames"
				),
				{
					params: {
						searchValue: ctrl.searchValue || "",
						limit: ctrl.requesterLimit
					}
				}
			)
				.then(function(res) {

					var data = res.data || [];

					ctrl.requestersList = data;

					// If backend returns less than limit, no more data
					ctrl.hasMoreRequesterData = data.length >= ctrl.requesterLimit;
				})
				.catch(function() {
					ctrl.requestersList = [];
				})
				.finally(function() {
					ctrl.isRequesterLoading = false;
				});
		};


		// 🔹 Load More
		ctrl.loadMoreButton = function() {
			ctrl.requesterLimit += 5;
			ctrl.fetchRequesters();
		};


		// 🔹 Show Load More Button
		ctrl.hasMoreButton = function() {
			return ctrl.hasMoreRequesterData && !ctrl.isRequesterLoading;
		};

		// ================================
		// Requestee Dropdown (Mirror Logic)
		// ================================

		ctrl.searchFilterRequestees = "";
		ctrl.requesteesList = [];

		ctrl.requesteeLimit = 5;
		ctrl.requesteeOffset = 0;

		ctrl.isRequesteeLoading = false;
		ctrl.hasMoreRequesteeData = true;

		var requesteeDebouncePromise = null;


		// 🔹 Reset State
		ctrl.resetRequesteeState = function() {
			ctrl.requesteeLimit = 5;
			ctrl.requesteesList = [];
			ctrl.hasMoreRequesteeData = true;
		};


		// 🔹 Open Dropdown
		ctrl.openRequesteeDropdown = function() {
			if (ctrl.showRequesteesDropdown) return;

			ctrl.showRequesteesDropdown = true;
			ctrl.resetRequesteeState();
			ctrl.fetchRequestees();
		};


		// 🔹 Toggle Dropdown
		ctrl.toggleRequesteeDropdown = function() {
			ctrl.showRequesteesDropdown = !ctrl.showRequesteesDropdown;

			if (ctrl.showRequesteesDropdown) {
				ctrl.resetRequesteeState();
				ctrl.fetchRequestees();
			}
		};


		// 🔹 Debounced Search
		ctrl.onRequesteeSearchChange = function() {

			if (!ctrl.showRequesteesDropdown) {
				ctrl.showRequesteesDropdown = true;
			}

			if (requesteeDebouncePromise) {
				$timeout.cancel(requesteeDebouncePromise);
			}

			requesteeDebouncePromise = $timeout(function() {
				ctrl.resetRequesteeState();
				ctrl.fetchRequestees();
			}, 400);
		};


		// 🔹 Fetch API
		ctrl.fetchRequestees = function() {

			if (ctrl.isRequesteeLoading || !ctrl.hasMoreRequesteeData) {
				return;
			}

			ctrl.isRequesteeLoading = true;

			$http.get(
				PluginHelper.getPluginRestUrl(
					"AccessRequestArchivalPlugin/search/identityNames" // adjust endpoint if needed
				),
				{
					params: {
						searchValue: ctrl.searchFilterRequestees || "",
						limit: ctrl.requesteeLimit
					}
				}
			)
				.then(function(res) {

					var data = res.data || [];

					ctrl.requesteesList = data;

					ctrl.hasMoreRequesteeData = data.length >= ctrl.requesteeLimit;
				})
				.catch(function() {
					ctrl.requesteesList = [];
				})
				.finally(function() {
					ctrl.isRequesteeLoading = false;
				});
		};


		// 🔹 Load More
		ctrl.loadMoreRequesteeButton = function() {

			ctrl.requesteeLimit += 5;
			ctrl.fetchRequestees();
		};


		// ==============================
		// FETCH FILTER DATA
		// ==============================

		ctrl.toggleFilter = function() {
			ctrl.showFilterPanel = !ctrl.showFilterPanel;
		};

		// ==============================
		// APPLICATION FILTERING
		// ==============================

		ctrl.getFilteredApplications = function() {

			if (!ctrl.searchApplication) {
				return ctrl.archivalIRApplicationsToShow;
			}

			var search = ctrl.searchApplication.toLowerCase();

			return ctrl.archivalIRApplications
				.filter(function(app) {
					return app.toLowerCase().indexOf(search) !== -1;
				})
				.slice(0, ctrl.archivalIRApplicationsToShow.length);
		};

		// ==============================
		// APPLICATION PAGINATION
		// ==============================

		ctrl.hasMoreApplications = function() {

			if (!ctrl.archivalIRApplications ||
				!ctrl.archivalIRApplicationsToShow) {
				return false;
			}

			return ctrl.archivalIRApplicationsToShow.length <
				ctrl.archivalIRApplications.length;
		};


		ctrl.loadMoreApplications = function() {

			if (!ctrl.archivalIRApplicationsToShow) {
				return;
			}

			var next = ctrl.archivalIRApplicationsToShow.length;

			ctrl.archivalIRApplicationsToShow =
				ctrl.archivalIRApplications.slice(0, next + 10);
		};

		// Generic toggle selection
		ctrl.toggleSelection = function(value, fieldName) {
			ctrl.criteriaArchivalIR = ctrl.criteriaArchivalIR || {};
			ctrl.criteriaArchivalIR[fieldName] = ctrl.criteriaArchivalIR[fieldName] || [];

			const list = ctrl.criteriaArchivalIR[fieldName];
			const index = list.indexOf(value);
			if (index > -1) {
				list.splice(index, 1); // Deselect
			} else {
				list.push(value); // Select
			}
		};

		// Filter function specific for Requester
		ctrl.getFilteredRequesters = function() {
			const searchText = ctrl.searchValue || '';
			const listToShow = ctrl.archivalIRRequestersToShow || [];

			if (!searchText) return listToShow;

			return ctrl.archivalIRIdentities.filter(function(name) {
				return name.toLowerCase().includes(searchText.toLowerCase());
			});
		};

		// Load more & has more for Requester
		ctrl.loadMoreRequesters = function() {
			var showArr = ctrl.archivalIRRequestersToShow || [];
			var nextItems = ctrl.archivalIRIdentities.slice(showArr.length, showArr.length + 10);
			ctrl.archivalIRRequestersToShow = showArr.concat(nextItems);
		};

		ctrl.hasMoreRequesters = function() {
			return (ctrl.archivalIRRequestersToShow || []).length < (ctrl.archivalIRIdentities || []).length;
		};

		// Filter function specific for Requestee
		ctrl.getFilteredRequestees = function() {
			const searchText = ctrl.searchFilterRequestees || '';
			const listToShow = ctrl.archivalIRRequesteesToShow || [];

			if (!searchText) return listToShow;

			return ctrl.archivalIRIdentities.filter(function(name) {
				return name.toLowerCase().includes(searchText.toLowerCase());
			});
		};

		// Load more & has more for Requestee
		ctrl.loadMoreRequestees = function() {
			const showArr = ctrl.archivalIRRequesteesToShow || [];
			const nextItems = ctrl.archivalIRIdentities.slice(showArr.length, showArr.length + 10);
			ctrl.archivalIRRequesteesToShow = showArr.concat(nextItems);
		};

		ctrl.hasMoreRequestees = function() {
			return (ctrl.archivalIRRequesteesToShow || []).length < (ctrl.archivalIRIdentities || []).length;
		};


		// Close dropdown when clicking outside
		document.addEventListener('click', function(event) {
			var needsDigest = false;

			// Requester dropdown
			var requesterDropdown = document.querySelector('.requesterField');
			if (requesterDropdown && !requesterDropdown.contains(event.target) && ctrl.showRequesterDropdown) {
				ctrl.showRequesterDropdown = false;
				needsDigest = true;
			}

			// Requestee dropdown
			var requesteeDropdown = document.querySelector('.requesteesField');
			if (requesteeDropdown && !requesteeDropdown.contains(event.target) && ctrl.showRequesteesDropdown) {
				ctrl.showRequesteesDropdown = false;
				needsDigest = true;
			}

			if (needsDigest) {
				$timeout(function() {});
			}
		});

		// Initialize
		ctrl.allRequestTypes = [
			'Request Access', 'Attribute Synchronization', 'Request Roles', 'Request Entitlements',
			'Manage Accounts', 'Expire Password', 'Forgot Password', 'Request Password',
			'Create Identity', 'Edit Identity', 'Registration', 'Lifecycle Leaver'
		];

		// Store selections here (hidden)
		ctrl.selectedTypesInternal = [];

		// Dropdown toggle
		ctrl.showRequestTypeDropdown = false;
		ctrl.requestTypeSearch = '';

		// Toggle selection
		ctrl.toggleRequestType = function(type, event) {
			event.stopPropagation();

			const index = ctrl.selectedTypesInternal.indexOf(type);

			if (index === -1) {
				ctrl.selectedTypesInternal.push(type);
			} else {
				ctrl.selectedTypesInternal.splice(index, 1);
			}
		};


		document.addEventListener('click', function(event) {
			var dropdown = document.querySelector('.archivalIRItemType .archivalIRDropdown');
			if (dropdown && !dropdown.contains(event.target) && ctrl.showRequestTypeDropdown) {
				$timeout(function() {
					ctrl.showRequestTypeDropdown = false;
				});
			}
		});

		// ================================
		//  SORT ORDER TOGGLE
		// ================================
		ctrl.sortOrder = "desc"; // default

		ctrl.toggleSortOrder = function() {
			// Toggle sort order
			ctrl.sortOrder = ctrl.sortOrder === "asc" ? "desc" : "asc";

			// Re-fetch data based on current mode
			if (ctrl.isFilterMode) {
				// Fetch filtered requests with new sort
				ctrl.applyFilter(true); // true = pagination/refresh call
			} else {
				// Fetch search results with new sort
				ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
			}
		};

		// Page size dropdown
		ctrl.dropupOpen = false;

		ctrl.toggleDropup = function() {
			ctrl.dropupOpen = !ctrl.dropupOpen;
		};

		ctrl.changeSize = function(size) {
			ctrl.size = size;
			ctrl.dropupOpen = false;
			ctrl.page = 1;
			if (ctrl.isFilterMode) {
				ctrl.applyFilter(true);
			} else {
				ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
			}
		};

		// Close page-size dropup when clicking outside
		document.addEventListener('click', function(event) {
			var dropup = document.querySelector('.page-size-dropup-container');
			if (dropup && !dropup.contains(event.target) && ctrl.dropupOpen) {
				$timeout(function() {
					ctrl.dropupOpen = false;
				});
			}
		});

		ctrl.getBackendPoint = function(searchTerm, page) {
			ctrl.page = page || ctrl.page;

			if (ctrl.isFilterMode) {
				// If search term is empty → reload normal filter results
				if (!searchTerm || searchTerm.trim() === "") {
					ctrl.applyFilter(true);   // ❗ do NOT pass searchTerm
				}
				else {
					// If search term exists → search within filter
					ctrl.applyFilter(true, searchTerm);
				}

				return; // stop normal search call
			}

			if (!searchTerm || searchTerm.trim() === "") {
				ctrl.requests = [];
				ctrl.showDiv = false;
				ctrl.errorMessage = "";
				return;
			}

			var normalizedSearchTerm = ctrl.normalizeSearchTerm(searchTerm);

			$http({
				method: 'GET',
				url: PluginHelper.getPluginRestUrl("AccessRequestArchivalPlugin/search/identityrequests"),
				params: {
					searchTerm: normalizedSearchTerm,
					page: ctrl.page,
					size: ctrl.size,
					sort: ctrl.selectedSort,
					sortOrder: ctrl.sortOrder
				}
			}).then(function(response) {
				var data = response.data;
				var reqList = data.requests || [];
				console.log("Request Objects: ", data);
				ctrl.total = data.total || 0;
				console.log("This is the url: ", PluginHelper.getPluginRestUrl);
				ctrl.requests = reqList.map(req => {
					const identityRequestItem = req.identityRequestItem || [];
					return {
						requestType: req.type || "",
						targetDisplayName: req.targetDisplayName || "",
						requestedBy: req.requesterDisplayName || "",
						applicationName: req.applicationName || "",
						entitlementName: req.entitlementName || "",
						createdDate: req.created ? new Date(Number(req.created)).toLocaleDateString('en-GB', {
							year: '2-digit', month: '2-digit', day: '2-digit'
						}) : "",
						requestId: req.name,
						completionStatus: req.completionStatus,
						operationValue: identityRequestItem.map(item => ({
							operation: item.operation || '',
							value: item.value || '',
							application: item.application || '',
							displayItem: item.displayItem,
							displayStatus: item.displayStatus || '',
							requestOperation: item.name || ''
							//, uiStatus: item.uiStatus || ''
						}))
					};
				});

				ctrl.totalPages = Math.ceil(ctrl.total / ctrl.size);
				ctrl.currentPage = ctrl.page;
				ctrl.pageInput = ctrl.page + "";

				ctrl.pages = [];
				for (var i = 1; i <= ctrl.totalPages; i++) {
					ctrl.pages.push(i);
				}
				ctrl.showDiv = true;
				ctrl.errorMessage = "";
			}, function(response) {
				ctrl.errorMessage = "Backend call failed! Status: " + response.status;
			});
		};

	
		ctrl.normalizeSearchTerm = function(term) {
			if (!term || term.trim() === "") {
				return "";
			}

			var normalized = term.trim();

			// If only digits → pad to 10
			if (/^\d+$/.test(normalized)) {
				normalized = normalized.padStart(10, "0");
			}
			return normalized;
		};


		// Initialize filter object (merge all fields into single definition)
		ctrl.criteriaArchivalIR = {
			selectedRequesters: [],
			selectedRequestees: [],
			selectedApplications: [],
			startDate: null,
			endDate: null,
			selectedTypes: [],
			selectedPriority: null,
			selectedStatus: null
		};

		// Apply Filter function
		ctrl.activeFilterSearchTerm = "";   // <-- persistent search term for filtered mode

		ctrl.applyFilter = function(isPaginationCall, searchTermFromSearchBox) {

			// If user typed a new search term (Enter pressed), update the stored one
			if (searchTermFromSearchBox && searchTermFromSearchBox.trim() !== "") {
				ctrl.activeFilterSearchTerm = ctrl.normalizeSearchTerm(searchTermFromSearchBox);
			}

			// Build payload
			const payload = {};

			if (ctrl.criteriaArchivalIR.selectedRequesters.length > 0)
				payload.requesters = ctrl.criteriaArchivalIR.selectedRequesters;

			if (ctrl.criteriaArchivalIR.selectedRequestees.length > 0)
				payload.requestees = ctrl.criteriaArchivalIR.selectedRequestees;

			if (ctrl.criteriaArchivalIR.startDate)
				payload.startDate = ctrl.criteriaArchivalIR.startDate;

			if (ctrl.criteriaArchivalIR.endDate)
				payload.endDate = ctrl.criteriaArchivalIR.endDate;

			if (ctrl.selectedTypesInternal && ctrl.selectedTypesInternal.length > 0)
				payload.types = ctrl.selectedTypesInternal;

			if (ctrl.criteriaArchivalIR.selectedPriority &&
				ctrl.criteriaArchivalIR.selectedPriority !== '--None--')
				payload.priority = ctrl.criteriaArchivalIR.selectedPriority;

			if (ctrl.criteriaArchivalIR.selectedStatus &&
				ctrl.criteriaArchivalIR.selectedStatus !== '--None--')
				payload.status = ctrl.criteriaArchivalIR.selectedStatus;

			ctrl.isFilterMode = true;

			// Reset page only when user manually applies filter, not during pagination
			if (!isPaginationCall) {
				ctrl.page = 1;
			}
			
			// Inject the persistent search term if any
			if (ctrl.activeFilterSearchTerm && ctrl.activeFilterSearchTerm.trim() !== "") {
				payload.searchTerm = ctrl.activeFilterSearchTerm;
			}

			payload.page = ctrl.page;
			payload.size = ctrl.size;
			payload.sort = ctrl.selectedSort;
			payload.sortOrder = ctrl.sortOrder;
			
			$http({
				method: 'POST',
				url: PluginHelper.getPluginRestUrl("AccessRequestArchivalPlugin/search/filteredRequests"),
				data: payload
			}).then(function(response) {

				const data = response.data;
				const reqList = data.requests || [];
				console.log("Request objects: ", reqList);
				ctrl.total = data.total || 0;
				ctrl.details = reqList || [];

				ctrl.requests = reqList.map(req => {
					const identityRequestItem = req.identityRequestItem || [];
					return {
						requestType: req.type || "",
						targetDisplayName: req.targetDisplayName || "",
						requestedBy: req.requesterDisplayName || "",
						applicationName: req.applicationName || "",
						entitlementName: req.entitlementName || "",
						createdDate: req.created ? new Date(Number(req.created)).toLocaleDateString('en-GB', {
							year: '2-digit', month: '2-digit', day: '2-digit'
						}) : "",
						requestId: req.name,
						completionStatus: req.completionStatus,
						operationValue: identityRequestItem.map(item => ({
							operation: item.operation || '',
							value: item.value || '',
							application: item.application || '',
							displayItem: item.displayItem || '',
							displayStatus: item.displayStatus || '',
							requestOperation: item.name  || ''
						}))
					};
				});

				ctrl.totalPages = Math.ceil(ctrl.total / ctrl.size);
				ctrl.currentPage = ctrl.page;
				ctrl.pageInput = ctrl.page + "";

				ctrl.pages = [];
				for (var i = 1; i <= ctrl.totalPages; i++) {
					ctrl.pages.push(i);
				}

				ctrl.showDiv = true;
				ctrl.showFilterPanel = false;

			}).catch(function() {
				ctrl.errorMessage = "Failed to fetch filtered requests.";
			});
		};


		ctrl.clearFilters = function() {

			ctrl.criteriaArchivalIR = {
				selectedRequesters: [],
				selectedRequestees: [],
				selectedApplications: [],
				startDate: null,
				endDate: null,
				selectedTypes: [],
				selectedPriority: '--None--',
				selectedStatus: '--None--'
			};

			ctrl.selectedTypesInternal = [];
			ctrl.requestSearchTerm = "";
			ctrl.page = 1;

			ctrl.isFilterMode = false;

			// reload default data
			ctrl.getBackendPoint("", 1);
			ctrl.showFilterPanel = false;
		};

		// ================================
		//  PAGINATION
		// ================================
		ctrl.nextPage = function() {
			if ((ctrl.page * ctrl.size) < ctrl.total) {
				ctrl.page++;
				ctrl.pageInput = ctrl.page;
				if (ctrl.isFilterMode) {
					// pagination for filtered results
					ctrl.applyFilter(true);
				} else {
					// pagination for search results
					ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
				}
			}
		};

		ctrl.prevPage = function() {
			if (ctrl.page > 1) {
				ctrl.page--;
				ctrl.pageInput = ctrl.page;
				if (ctrl.isFilterMode) {
					// pagination for filtered results
					ctrl.applyFilter(true);
				} else {
					// pagination for search results
					ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
				}
			}
		};

		ctrl.firstPage = function() {
			if (ctrl.page > 1) {
				ctrl.page = 1;
				ctrl.pageInput = ctrl.page;
				if (ctrl.isFilterMode) {
					ctrl.applyFilter(true);
				} else {
					ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
				}
			}
		};

		ctrl.lastPage = function() {
			const totalPages = Math.ceil(ctrl.total / ctrl.size);
			if (ctrl.page < totalPages) {
				ctrl.page = totalPages;
				ctrl.pageInput = ctrl.page;
				if (ctrl.isFilterMode) {
					ctrl.applyFilter(true);
				} else {
					ctrl.getBackendPoint(ctrl.searchTerm, ctrl.page);
				}
			}
		};

		ctrl.pageInput = ctrl.page + "";  // always store input as string

		ctrl.onPageKeyDown = function(event) {

			// ENTER key
			if (event.key === "Enter") {
				let raw = (ctrl.pageInput || "").replace(/[^0-9]/g, "");

				if (!raw || raw === "0") {
					// Invalid or empty entry → do nothing
					return;
				}

				let newPage = parseInt(raw, 10);
				const totalPages = Math.ceil(ctrl.total / ctrl.size);

				// clamp within range
				if (newPage < 1) newPage = 1;
				if (newPage > totalPages) newPage = totalPages;

				ctrl.page = newPage;
				ctrl.pageInput = newPage + "";

				// Fire API ONLY here
				if (ctrl.isFilterMode) {
					ctrl.applyFilter(true);
				} else {
					ctrl.getBackendPoint(ctrl.searchTerm, newPage);
				}

				return;
			}

			// For ALL other keys → filter invalid characters
			// (But do NOT stop user from typing multi digits)
			$timeout(function() {
				ctrl.pageInput = (ctrl.pageInput || "").replace(/[^0-9]/g, "");
			});
		};

		// ================================
		//  SEARCH
		// ================================
		ctrl.searchRequests = function() {
			const term = ctrl.searchTerm ? ctrl.searchTerm.trim() : "";

			if (term === "") {
				if (ctrl.isFilterMode) {
					// If in filter mode, clear any active search term and reload filtered results
					ctrl.activeFilterSearchTerm = ""; // Clear the persistent search term
					ctrl.page = 1;
					ctrl.applyFilter(true);
				} else {
					// Normal search mode: clear results
					ctrl.requests = [];
					ctrl.showDiv = false;
					ctrl.errorMessage = "";
					ctrl.total = 0;
				}
				return;
			}

			ctrl.page = 1;
			ctrl.getBackendPoint(term, ctrl.page);
		};

		// ================================
		//  DETAILS VIEW
		// ================================
		ctrl.showDetails = false;
		ctrl.selectedRequest = null;

		// ================================
		//  TABLE PAGINATION VARIABLES
		// ================================
		ctrl.requestItemsPageSize = 5;
		ctrl.requestItemsCurrentPage = 1;
		ctrl.requestItemsTotalPages = 1;

		ctrl.filteredItemsPageSize = 5;
		ctrl.filteredItemsCurrentPage = 1;
		ctrl.filteredItemsTotalPages = 1;

		ctrl.interactionsPageSize = 5;
		ctrl.interactionsCurrentPage = 1;
		ctrl.interactionsTotalPages = 1;

		ctrl.provisioningEnginePageSize = 5;
		ctrl.provisioningEngineCurrentPage = 1;
		ctrl.provisioningEngineTotalPages = 1;

		ctrl.errorsAndWarningsPageSize = 5;
		ctrl.errorsAndWarningsCurrentPage = 1;
		ctrl.errorsAndWarningsTotalPages = 1;

		// ================================
		//  TABLE PAGINATION FUNCTIONS
		// ================================

		// Returns up to 4 visible page numbers as a sliding window
		ctrl.getVisiblePages = function(currentPage, totalPages) {
			var maxVisible = 4;
			var pages = [];
			var startPage, endPage;

			if (totalPages <= maxVisible) {
				startPage = 1;
				endPage = totalPages;
			} else if (currentPage <= 2) {
				startPage = 1;
				endPage = maxVisible;
			} else if (currentPage >= totalPages - 1) {
				startPage = totalPages - maxVisible + 1;
				endPage = totalPages;
			} else {
				startPage = currentPage - 1;
				endPage = currentPage + 2;
			}

			for (var i = startPage; i <= endPage; i++) {
				pages.push(i);
			}
			return pages;
		};

		// Request Items Pagination
		ctrl.changeRequestItemsPageSize = function(size) {
			ctrl.requestItemsPageSize = size;
			ctrl.requestItemsCurrentPage = 1;
			ctrl.requestItemsTotalPages = Math.ceil((ctrl.selectedRequest && ctrl.selectedRequest.requestItems || []).length / size);
		};

		ctrl.nextRequestItemsPage = function() {
			if (ctrl.requestItemsCurrentPage < ctrl.requestItemsTotalPages) {
				ctrl.requestItemsCurrentPage++;
			}
		};

		ctrl.prevRequestItemsPage = function() {
			if (ctrl.requestItemsCurrentPage > 1) {
				ctrl.requestItemsCurrentPage--;
			}
		};

		ctrl.getRequestItemsForPage = function() {
			const start = (ctrl.requestItemsCurrentPage - 1) * ctrl.requestItemsPageSize;
			const end = start + ctrl.requestItemsPageSize;
			return (ctrl.selectedRequest && ctrl.selectedRequest.requestItems || []).slice(start, end);
		};

		ctrl.getRequestItemsShowingText = function() {
			const total = (ctrl.selectedRequest && ctrl.selectedRequest.requestItems || []).length;
			const start = (ctrl.requestItemsCurrentPage - 1) * ctrl.requestItemsPageSize + 1;
			const end = Math.min(ctrl.requestItemsCurrentPage * ctrl.requestItemsPageSize, total);
			return `Showing ${start}-${end} of ${total}`;
		};

		ctrl.goToRequestItemsPage = function(page) {
			if (page >= 1 && page <= ctrl.requestItemsTotalPages) {
				ctrl.requestItemsCurrentPage = page;
			}
		};

		// Filtered Items Pagination
		ctrl.changeFilteredItemsPageSize = function(size) {
			ctrl.filteredItemsPageSize = size;
			ctrl.filteredItemsCurrentPage = 1;
			ctrl.filteredItemsTotalPages = Math.ceil((ctrl.selectedRequest.filteredItems || []).length / size);
		};

		ctrl.nextFilteredItemsPage = function() {
			if (ctrl.filteredItemsCurrentPage < ctrl.filteredItemsTotalPages) {
				ctrl.filteredItemsCurrentPage++;
			}
		};

		ctrl.prevFilteredItemsPage = function() {
			if (ctrl.filteredItemsCurrentPage > 1) {
				ctrl.filteredItemsCurrentPage--;
			}
		};

		ctrl.getFilteredItemsForPage = function() {
			const start = (ctrl.filteredItemsCurrentPage - 1) * ctrl.filteredItemsPageSize;
			const end = start + ctrl.filteredItemsPageSize;
			return (ctrl.selectedRequest && ctrl.selectedRequest.filteredItems || []).slice(start, end);
		};

		ctrl.getFilteredItemsShowingText = function() {
			const total = (ctrl.selectedRequest && ctrl.selectedRequest.filteredItems || []).length;
			const start = (ctrl.filteredItemsCurrentPage - 1) * ctrl.filteredItemsPageSize + 1;
			const end = Math.min(ctrl.filteredItemsCurrentPage * ctrl.filteredItemsPageSize, total);
			return `Showing ${start}-${end} of ${total}`;
		};

		ctrl.goToFilteredItemsPage = function(page) {
			if (page >= 1 && page <= ctrl.filteredItemsTotalPages) {
				ctrl.filteredItemsCurrentPage = page;
			}
		};

		// Interactions Pagination
		ctrl.changeInteractionsPageSize = function(size) {
			ctrl.interactionsPageSize = size;
			ctrl.interactionsCurrentPage = 1;
			ctrl.interactionsTotalPages = Math.ceil((ctrl.selectedRequest && ctrl.selectedRequest.interactions || []).length / size);
		};

		ctrl.nextInteractionsPage = function() {
			if (ctrl.interactionsCurrentPage < ctrl.interactionsTotalPages) {
				ctrl.interactionsCurrentPage++;
			}
		};

		ctrl.prevInteractionsPage = function() {
			if (ctrl.interactionsCurrentPage > 1) {
				ctrl.interactionsCurrentPage--;
			}
		};

		ctrl.getInteractionsForPage = function() {
			const start = (ctrl.interactionsCurrentPage - 1) * ctrl.interactionsPageSize;
			const end = start + ctrl.interactionsPageSize;
			return (ctrl.selectedRequest && ctrl.selectedRequest.interactions || []).slice(start, end);
		};

		ctrl.getInteractionsShowingText = function() {
			const total = (ctrl.selectedRequest && ctrl.selectedRequest.interactions || []).length;
			const start = (ctrl.interactionsCurrentPage - 1) * ctrl.interactionsPageSize + 1;
			const end = Math.min(ctrl.interactionsCurrentPage * ctrl.interactionsPageSize, total);
			return `Showing ${start}-${end} of ${total}`;
		};

		ctrl.goToInteractionsPage = function(page) {
			if (page >= 1 && page <= ctrl.interactionsTotalPages) {
				ctrl.interactionsCurrentPage = page;
			}
		};

		// Provisioning Engine Pagination
		ctrl.changeProvisioningEnginePageSize = function(size) {
			ctrl.provisioningEnginePageSize = size;
			ctrl.provisioningEngineCurrentPage = 1;
			ctrl.provisioningEngineTotalPages = Math.ceil((ctrl.selectedRequest && ctrl.selectedRequest.provisioningEngine || []).length / size);
		};

		ctrl.nextProvisioningEnginePage = function() {
			if (ctrl.provisioningEngineCurrentPage < ctrl.provisioningEngineTotalPages) {
				ctrl.provisioningEngineCurrentPage++;
			}
		};

		ctrl.prevProvisioningEnginePage = function() {
			if (ctrl.provisioningEngineCurrentPage > 1) {
				ctrl.provisioningEngineCurrentPage--;
			}
		};

		ctrl.getProvisioningEngineForPage = function() {
			const start = (ctrl.provisioningEngineCurrentPage - 1) * ctrl.provisioningEnginePageSize;
			const end = start + ctrl.provisioningEnginePageSize;
			return (ctrl.selectedRequest && ctrl.selectedRequest.provisioningEngine || []).slice(start, end);
		};

		ctrl.getProvisioningEngineShowingText = function() {
			const total = (ctrl.selectedRequest && ctrl.selectedRequest.provisioningEngine || []).length;
			const start = (ctrl.provisioningEngineCurrentPage - 1) * ctrl.provisioningEnginePageSize + 1;
			const end = Math.min(ctrl.provisioningEngineCurrentPage * ctrl.provisioningEnginePageSize, total);
			return `Showing ${start}-${end} of ${total}`;
		};

		ctrl.goToProvisioningEnginePage = function(page) {
			if (page >= 1 && page <= ctrl.provisioningEngineTotalPages) {
				ctrl.provisioningEngineCurrentPage = page;
			}
		};

		// Errors and Warnings Pagination
		ctrl.changeErrorsAndWarningsPageSize = function(size) {
			ctrl.errorsAndWarningsPageSize = size;
			ctrl.errorsAndWarningsCurrentPage = 1;
			ctrl.errorsAndWarningsTotalPages = Math.ceil((ctrl.selectedRequest.errorsAndWarnings || []).length / size);
		};

		ctrl.nextErrorsAndWarningsPage = function() {
			if (ctrl.errorsAndWarningsCurrentPage < ctrl.errorsAndWarningsTotalPages) {
				ctrl.errorsAndWarningsCurrentPage++;
			}
		};

		ctrl.prevErrorsAndWarningsPage = function() {
			if (ctrl.errorsAndWarningsCurrentPage > 1) {
				ctrl.errorsAndWarningsCurrentPage--;
			}
		};

		ctrl.getErrorsAndWarningsForPage = function() {
			const start = (ctrl.errorsAndWarningsCurrentPage - 1) * ctrl.errorsAndWarningsPageSize;
			const end = start + ctrl.errorsAndWarningsPageSize;
			return (ctrl.selectedRequest && ctrl.selectedRequest.errorsAndWarnings || []).slice(start, end);
		};

		ctrl.getErrorsAndWarningsShowingText = function() {
			const total = (ctrl.selectedRequest && ctrl.selectedRequest.errorsAndWarnings || []).length;
			const start = (ctrl.errorsAndWarningsCurrentPage - 1) * ctrl.errorsAndWarningsPageSize + 1;
			const end = Math.min(ctrl.errorsAndWarningsCurrentPage * ctrl.errorsAndWarningsPageSize, total);
			return `Showing ${start}-${end} of ${total}`;
		};

		ctrl.goToErrorsAndWarningsPage = function(page) {
			if (page >= 1 && page <= ctrl.errorsAndWarningsTotalPages) {
				ctrl.errorsAndWarningsCurrentPage = page;
			}
		};

		// Track which requestId is currently being fetched to prevent race conditions
		ctrl._pendingDetailsRequestId = null;
		ctrl.isLoadingDetails = false;
		ctrl.detailsErrorMessage = "";

		ctrl.openDetails = function(requestId) {
			ctrl.showFilterPanel = false;
			ctrl.showDiv = false;
			ctrl.showDetails = true;
			ctrl.isLoadingDetails = true;
			ctrl.detailsErrorMessage = "";
			ctrl.selectedRequest = {};

			// Reset ALL detail table pagination to page 1
			ctrl.requestItemsCurrentPage = 1;
			ctrl.filteredItemsCurrentPage = 1;
			ctrl.interactionsCurrentPage = 1;
			ctrl.provisioningEngineCurrentPage = 1;
			ctrl.errorsAndWarningsCurrentPage = 1;

			// Reset total pages
			ctrl.requestItemsTotalPages = 1;
			ctrl.filteredItemsTotalPages = 1;
			ctrl.interactionsTotalPages = 1;
			ctrl.provisioningEngineTotalPages = 1;
			ctrl.errorsAndWarningsTotalPages = 1;

			// Reset classification popup
			ctrl.openClassificationIndex = null;

			// Guard against race condition: track which request we're waiting for
			ctrl._pendingDetailsRequestId = requestId;
			
			$http({
				method: 'GET',
				url: PluginHelper.getPluginRestUrl("AccessRequestArchivalPlugin/search/identityrequestdetails"),
				params: {
					requestId: requestId
				}
			}).then(function(response) {
				// Race condition guard: ignore response if user clicked a different request
				if (ctrl._pendingDetailsRequestId !== requestId) {
					return;
				}

				var selected = response.data;
				if (!selected) {
					ctrl.detailsErrorMessage = "No data returned for this request.";
					ctrl.isLoadingDetails = false;
					return;
				}

				// Null-safe access to allTablesData
				var tablesData = selected.allTablesData || {};

				ctrl.selectedRequest.requestId = selected.name || "";
				ctrl.selectedRequest.requestedBy = selected.requesterDisplayName || "";
				ctrl.selectedRequest.targetDisplayName = selected.targetDisplayName || "";
				ctrl.selectedRequest.requestType = selected.type || "";
				ctrl.selectedRequest.completionDate = selected.endDate || "";
				ctrl.selectedRequest.verificationDate = selected.verified || "";
				ctrl.selectedRequest.currentStep = selected.state;
				ctrl.selectedRequest.priority = selected.priority;
				ctrl.selectedRequest.createdDate = selected.created || "";
				ctrl.selectedRequest.executionStatus = selected.executionStatus || "";
				ctrl.selectedRequest.completionStatus = selected.completionStatus || "";

				ctrl.selectedRequest.requestItems = tablesData.requestItems || [];
				ctrl.selectedRequest.filteredItems = tablesData.filteredItems || [];
				ctrl.selectedRequest.interactions = tablesData.interactions || [];
				ctrl.selectedRequest.provisioningEngine = tablesData.provisioningEngine || [];
				ctrl.selectedRequest.errorsAndWarnings = tablesData.errorsAndWarnings || [];
				console.log("Details Data: ", response.data);

				// Recalculate total pages
				ctrl.requestItemsTotalPages = Math.ceil(
					ctrl.selectedRequest.requestItems.length / ctrl.requestItemsPageSize
				) || 1;
				ctrl.filteredItemsTotalPages = Math.ceil(
					ctrl.selectedRequest.filteredItems.length / ctrl.filteredItemsPageSize
				) || 1;
				ctrl.interactionsTotalPages = Math.ceil(
					ctrl.selectedRequest.interactions.length / ctrl.interactionsPageSize
				) || 1;
				ctrl.provisioningEngineTotalPages = Math.ceil(
					ctrl.selectedRequest.provisioningEngine.length / ctrl.provisioningEnginePageSize
				) || 1;
				ctrl.errorsAndWarningsTotalPages = Math.ceil(
					ctrl.selectedRequest.errorsAndWarnings.length / ctrl.errorsAndWarningsPageSize
				) || 1;

				ctrl.isLoadingDetails = false;
				$window.scrollTo(0, 0);
			}, function(error) {
				if (ctrl._pendingDetailsRequestId !== requestId) {
					return;
				}
				ctrl.detailsErrorMessage = "Failed to load request details. Please try again.";
				ctrl.isLoadingDetails = false;
			});
		};

		// Track which row's classification popup is open
		ctrl.openClassificationIndex = null;

		ctrl.toggleClassification = function(index) {
			if (ctrl.openClassificationIndex === index) {
				ctrl.openClassificationIndex = null; // close
			} else {
				ctrl.openClassificationIndex = index; // open this one
			}
		};

		// Close popup when clicking anywhere outside
		document.addEventListener('click', function(event) {
			var popup = document.querySelector('.classification-popup');
			var icon = document.querySelector('.classification-icon');

			if (popup && !popup.contains(event.target) &&
				icon && !icon.contains(event.target) &&
				ctrl.openClassificationIndex !== null) {
				$timeout(function() {
					ctrl.openClassificationIndex = null;
				});
			}
		});

		ctrl.backToList = function() {
			ctrl.showDetails = false;
			ctrl.showDiv = true;
			ctrl.selectedRequest = null;
		};

		// ================================
		// DARK MODE TOGGLE
		// ================================
		ctrl.initDarkModeToggle = function() {
			const toggle = document.getElementById('archival-theme-toggle');

			if (!toggle) return;

			// Load saved theme
			const savedTheme = localStorage.getItem('archival-theme') || 'light';
			document.body.setAttribute('data-theme', savedTheme);
			toggle.checked = savedTheme === 'dark';

			// Listen for toggle changes
			toggle.addEventListener('change', function() {
				const theme = this.checked ? 'dark' : 'light';
				document.body.setAttribute('data-theme', theme);
				localStorage.setItem('archival-theme', theme);
			});
		};

		// Run after DOM ready
		$timeout(ctrl.initDarkModeToggle, 500);}]);
