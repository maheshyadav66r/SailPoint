package com.endpointstest.demo.EndPointsDemoOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndPointsDemoOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
