package com.endpointstest.demo.EndPointsDemoOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndPointsDemoOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndPointsDemoOneApplication.class, args);
	}

}
